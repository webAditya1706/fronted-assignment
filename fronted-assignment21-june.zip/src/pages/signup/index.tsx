import SignUp from "@/constant/SignUp"
export default SignUp