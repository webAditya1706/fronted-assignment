import SignUp from "../signup";
export default SignUp;