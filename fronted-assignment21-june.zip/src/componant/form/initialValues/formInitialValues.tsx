const signUpInitialValues = {
  name: "",
  email: "",
  contact:"",
  password: "",
  confirmPassword: "",
  role:"",
  logo:""
};
const signInInitialValues={
  email: "",
  password: "",
}

export { signUpInitialValues, signInInitialValues };
