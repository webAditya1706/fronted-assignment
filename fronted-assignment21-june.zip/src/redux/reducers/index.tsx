import { combineReducers } from "@reduxjs/toolkit";
import FormReducer from "./formReducer";

const rootReducer = combineReducers({
  FormReducer,
});

export default rootReducer;
